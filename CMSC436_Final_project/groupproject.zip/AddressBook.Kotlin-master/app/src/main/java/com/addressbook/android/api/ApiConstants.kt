package com.addressbook.android.api


//put all api call related keys data here
object ApiConstants {
    var BASE_URL = "https://postman-echo.com/"
}