package com.addressbook.android.util

object Constant {
    const val MM_secrets = "secrets"
    const val AB_USER_MAP = "USER_MAP"
    const val Key_editAddressBook = "editAddressBook"
}