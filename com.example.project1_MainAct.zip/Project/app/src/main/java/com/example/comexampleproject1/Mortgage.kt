package com.example.comexampleproject1

import kotlin.math.pow

class Mortgage(private var year: Int, private var amount: Double, private var interestRate: Double) {

    fun yearGetter(): Int = year
    fun amountGetter(): Double = amount
    fun irGetter(): Double = interestRate

    fun yearSetter(year: Int) {
        this.year = year
    }

    fun amountSetter(amount: Double) {
        this.amount = amount
    }

    fun irSetter(interestRate: Double) {
        this.interestRate = interestRate
    }

    fun monthlyPayment() : Double {
        val monthlyInterestRate = interestRate / 12
        val a = 1 / (1 + monthlyInterestRate)
        val b = (a.pow(year * 12) - 1) / (a - 1)
        return amount / (a * b)
    }

    fun totalPayment() : Double {
        return monthlyPayment() * 12 * year
    }


    fun formattedMonthly() : String {
        return "$%.2f".format(monthlyPayment())
    }

    fun formattedTotal(): String {
        return "$%.2f".format(totalPayment())
    }
}