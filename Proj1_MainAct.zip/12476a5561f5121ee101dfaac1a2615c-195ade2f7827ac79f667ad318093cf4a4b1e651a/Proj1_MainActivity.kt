package com.example.comexampleproject1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val mortgage = Mortgage(30, 200000.0, 0.06)

        val monthly1 = mortgage.formattedMonthly()
        val total1 = mortgage.formattedTotal()

        Log.i("MainActivity", "Monthly Payment: $monthly1")
        Log.i("MainActivity", "Total Payment: $total1")

        mortgage.amountSetter(300000.0)
        mortgage.yearSetter(15)
        mortgage.irSetter(0.065)

        val monthly2 = mortgage.formattedMonthly()
        val total2 = mortgage.formattedTotal()

        Log.i("MainActivity", "Updated monthly: $monthly2")
        Log.i("MainActivity", "Updated Total: $total2")
    }
}